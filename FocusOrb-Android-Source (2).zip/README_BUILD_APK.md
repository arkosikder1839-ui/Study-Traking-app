# Focus Orb - Android APK Build Guide (Phone-Only & Desktop)

Target Device: Huawei Y9 Prime (Android 10 / EMUI 10, HiSilicon Kirin 710F)

---

### Option 1: Instant In-Browser PWA (Zero Build Required)
1. In your phone's browser (Huawei Browser or Chrome), tap the **Install App** button at the top of the Focus Orb app.
2. The app installs directly onto your home screen with its own launcher icon.
3. It runs in full-screen standalone mode, works 100% offline, and calculates background study time using system timestamps.

---

### Option 2: Build Native APK using Free GitHub Actions (From Phone)
You can build a real APK file directly from your phone without touching a computer:
1. Tap "Download Android Studio Project (.ZIP)" in the Export tab of Focus Orb.
2. Go to github.com on your phone and create a new repository called focus-orb.
3. Upload the unzipped files (or push using a phone Git app like MGit or Termux).
4. GitHub Actions will automatically detect .github/workflows/build-apk.yml and compile the APK in ~90 seconds.
5. Tap Actions -> Build Focus Orb Android APK -> download the FocusOrb-debug-apk.zip containing app-debug.apk.
6. Tap the app-debug.apk file to install it directly on your Huawei Y9 Prime!

---

### Option 3: Build directly on Phone with Termux
If you have Termux installed on your Huawei Y9 Prime:
1. Update packages and install OpenJDK 17:
   pkg update && pkg install openjdk-17 git wget
2. Extract Focus Orb project into your workspace:
   cd FocusOrb
3. Compile debug APK:
   ./gradlew assembleDebug
4. Find your generated APK at:
   app/build/outputs/apk/debug/app-debug.apk

---

### Key Features of this Native Android Codebase:
- OrbView.kt: Custom Canvas view using native RadialGradient and double-buffered ValueAnimator for 60fps rendering on Kirin 710F.
- TimerForegroundService.kt: Android 10 Foreground Service with PARTIAL_WAKE_LOCK and live status bar notification so the timer never stops when the screen is turned off.
- Room SQLite: Local AppDatabase storing all subjects and sessions with zero external network dependencies.
