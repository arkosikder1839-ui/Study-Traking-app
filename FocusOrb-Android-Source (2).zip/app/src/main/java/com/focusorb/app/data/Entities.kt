package com.focusorb.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "subjects")
data class SubjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val colorHex: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "study_sessions")
data class SessionEntity(
    @PrimaryKey val id: String,
    val subjectId: String,
    val subjectName: String,
    val durationSeconds: Int,
    val mode: String, // STUDY, SHORT_BREAK, LONG_BREAK
    val startTime: Long,
    val endTime: Long,
    val completed: Boolean
)
