package com.focusorb.app

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.focusorb.app.service.TimerForegroundService
import com.focusorb.app.ui.OrbView
import java.util.UUID

class MainActivity : AppCompatActivity() {

    private lateinit var orbView: OrbView
    private lateinit var tvTimer: TextView
    private lateinit var tvSubject: TextView
    private lateinit var tvStatus: TextView
    private lateinit var btnToggle: Button
    private lateinit var btnReset: Button

    private var isRunning = false
    private var totalSeconds = 25 * 60
    private var remainingSeconds = totalSeconds
    private var countDownTimer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        orbView = findViewById(R.id.orbView)
        tvTimer = findViewById(R.id.tvTimer)
        tvSubject = findViewById(R.id.tvSubject)
        tvStatus = findViewById(R.id.tvStatus)
        btnToggle = findViewById(R.id.btnToggle)
        btnReset = findViewById(R.id.btnReset)

        updateTimerDisplay()
        orbView.setMode(OrbView.Mode.IDLE)

        btnToggle.setOnClickListener {
            if (isRunning) {
                pauseTimer()
            } else {
                startTimer()
            }
        }

        btnReset.setOnClickListener {
            resetTimer()
        }

        orbView.setOnClickListener {
            if (!isRunning) startTimer() else pauseTimer()
        }
    }

    private fun startTimer() {
        isRunning = true
        btnToggle.text = "PAUSE"
        tvStatus.text = "STUDY FOCUS"
        orbView.setMode(OrbView.Mode.STUDY)

        // Start Foreground Service for Android 10 background persistence
        val serviceIntent = Intent(this, TimerForegroundService::class.java).apply {
            putExtra("DURATION_SECONDS", remainingSeconds)
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }

        countDownTimer = object : CountDownTimer(remainingSeconds * 1000L, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                remainingSeconds = (millisUntilFinished / 1000).toInt()
                val progress = ((totalSeconds - remainingSeconds).toFloat() / totalSeconds.toFloat()) * 100f
                orbView.setProgress(progress)
                updateTimerDisplay()
            }

            override fun onFinish() {
                remainingSeconds = 0
                isRunning = false
                btnToggle.text = "START BREAK"
                tvStatus.text = "SESSION COMPLETE"
                orbView.setMode(OrbView.Mode.SHORT_BREAK)
                updateTimerDisplay()
            }
        }.start()
    }

    private fun pauseTimer() {
        isRunning = false
        countDownTimer?.cancel()
        btnToggle.text = "RESUME"
        tvStatus.text = "PAUSED"
        orbView.setMode(OrbView.Mode.PAUSED)
        stopService(Intent(this, TimerForegroundService::class.java))
    }

    private fun resetTimer() {
        isRunning = false
        countDownTimer?.cancel()
        remainingSeconds = totalSeconds
        orbView.setProgress(0f)
        orbView.setMode(OrbView.Mode.IDLE)
        btnToggle.text = "START STUDY"
        tvStatus.text = "READY"
        updateTimerDisplay()
        stopService(Intent(this, TimerForegroundService::class.java))
    }

    private fun updateTimerDisplay() {
        val minutes = remainingSeconds / 60
        val seconds = remainingSeconds % 60
        tvTimer.text = String.format("%02d:%02d", minutes, seconds)
    }

    override fun onDestroy() {
        countDownTimer?.cancel()
        super.onDestroy()
    }
}
