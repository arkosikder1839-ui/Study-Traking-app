package com.focusorb.app.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.*
import androidx.core.app.NotificationCompat
import com.focusorb.app.MainActivity

/**
 * Foreground Service ensuring timer calculation continues reliably in Android 10
 * when phone screen is turned off or device enters Doze mode.
 */
class TimerForegroundService : Service() {

    private val CHANNEL_ID = "focus_orb_channel"
    private var isRunning = false
    private var targetEndTime: Long = 0L
    private val handler = Handler(Looper.getMainLooper())
    private var wakeLock: PowerManager.WakeLock? = null

    private val tickRunnable = object : Runnable {
        override fun run() {
            if (!isRunning) return
            val remainingSec = ((targetEndTime - System.currentTimeMillis()) / 1000).coerceAtLeast(0)
            updateNotification(remainingSec)

            if (remainingSec <= 0) {
                onTimerFinished()
            } else {
                handler.postDelayed(this, 1000)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "FocusOrb:TimerWakeLock").apply {
            setReferenceCounted(false)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val durationSeconds = intent?.getIntExtra("DURATION_SECONDS", 25 * 60) ?: (25 * 60)
        targetEndTime = System.currentTimeMillis() + (durationSeconds * 1000L)
        isRunning = true
        wakeLock?.acquire(durationSeconds * 1000L + 5000L)

        startForeground(1001, buildNotification(durationSeconds.toLong()))
        handler.post(tickRunnable)

        return START_NOT_STICKY
    }

    private fun updateNotification(remainingSec: Long) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(1001, buildNotification(remainingSec))
    }

    private fun buildNotification(remainingSec: Long): Notification {
        val minutes = remainingSec / 60
        val seconds = remainingSec % 60
        val timeString = String.format("%02d:%02d", minutes, seconds)

        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Focus Orb - Deep Study")
            .setContentText("Time Remaining: $timeString")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun onTimerFinished() {
        isRunning = false
        wakeLock?.release()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Study Timer Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps study timer active in background"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        isRunning = false
        handler.removeCallbacks(tickRunnable)
        if (wakeLock?.isHeld == true) {
            wakeLock?.release()
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
