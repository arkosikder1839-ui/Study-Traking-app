package com.focusorb.app.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.*
import kotlin.random.Random

/**
 * High-performance hardware-accelerated Glowing AI Orb for Android 10.
 * Renders multi-ring orbital particle halos and dynamic radial gradients.
 */
class OrbView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    enum class Mode {
        STUDY, SHORT_BREAK, LONG_BREAK, PAUSED, IDLE
    }

    private var currentMode = Mode.IDLE
    private var progressPercent: Float = 0f

    // Paints
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(24f, 16f), 0f)
    }
    private val progressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 10f
    }
    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG)

    // Animation & Timing
    private var animTime = 0f
    private val animator = ValueAnimator.ofFloat(0f, 10000f).apply {
        duration = 100000L
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            animTime += 0.05f
            invalidate()
        }
    }

    // Particles
    private data class Particle(
        var angle: Float,
        var angularSpeed: Float,
        var distance: Float,
        var size: Float,
        var alpha: Int,
        var color: Int
    )

    private val particles = ArrayList<Particle>()

    init {
        // Prepare 36 orbiting ambient particles
        for (i in 0 until 36) {
            particles.add(
                Particle(
                    angle = Random.nextFloat() * 6.28f,
                    angularSpeed = (Random.nextFloat() * 0.02f + 0.01f) * if (Random.nextBoolean()) 1f else -1f,
                    distance = Random.nextFloat() * 140f + 60f,
                    size = Random.nextFloat() * 4f + 2f,
                    alpha = Random.nextInt(120, 240),
                    color = Color.parseColor("#00F0FF")
                )
            )
        }
        animator.start()
    }

    fun setMode(mode: Mode) {
        this.currentMode = mode
        updateThemeColors()
        invalidate()
    }

    fun setProgress(progress: Float) {
        this.progressPercent = progress.coerceIn(0f, 100f)
        invalidate()
    }

    private fun updateThemeColors() {
        val baseColor = when (currentMode) {
            Mode.STUDY -> Color.parseColor("#00F0FF")
            Mode.SHORT_BREAK, Mode.LONG_BREAK -> Color.parseColor("#10B981")
            Mode.PAUSED -> Color.parseColor("#F59E0B")
            Mode.IDLE -> Color.parseColor("#818CF8")
        }
        ringPaint.color = Color.argb(60, Color.red(baseColor), Color.green(baseColor), Color.blue(baseColor))
        progressPaint.color = baseColor
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val minDim = min(width, height)
        val baseRadius = minDim * 0.28f

        // Breathing oscillation
        val pulse = sin(animTime * 1.5f) * 10f
        val currentRadius = baseRadius + pulse

        // 1. Outer Glowing Aura
        val glowColors = when (currentMode) {
            Mode.STUDY -> intArrayOf(Color.parseColor("#6000F0FF"), Color.parseColor("#203B82F6"), Color.TRANSPARENT)
            Mode.SHORT_BREAK, Mode.LONG_BREAK -> intArrayOf(Color.parseColor("#6010B981"), Color.parseColor("#2006B6D4"), Color.TRANSPARENT)
            Mode.PAUSED -> intArrayOf(Color.parseColor("#60F59E0B"), Color.parseColor("#209333EA"), Color.TRANSPARENT)
            Mode.IDLE -> intArrayOf(Color.parseColor("#406366F1"), Color.parseColor("#154C1D95"), Color.TRANSPARENT)
        }
        glowPaint.shader = RadialGradient(
            cx, cy, currentRadius * 1.7f,
            glowColors, floatArrayOf(0.1f, 0.6f, 1.0f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, currentRadius * 1.7f, glowPaint)

        // 2. Orbital Rings
        for (i in 0..2) {
            canvas.save()
            canvas.rotate((animTime * 15f * (if (i % 2 == 0) 1 else -1)) + (i * 60f), cx, cy)
            ringPaint.strokeWidth = 3f
            val rx = currentRadius * (1.2f + i * 0.2f)
            val ry = rx * 0.7f
            canvas.drawOval(cx - rx, cy - ry, cx + rx, cy + ry, ringPaint)
            canvas.restore()
        }

        // 3. Main Luminous Core
        val coreColors = when (currentMode) {
            Mode.STUDY -> intArrayOf(Color.WHITE, Color.parseColor("#00F0FF"), Color.parseColor("#3B82F6"), Color.parseColor("#1E1B4B"))
            Mode.SHORT_BREAK, Mode.LONG_BREAK -> intArrayOf(Color.WHITE, Color.parseColor("#34D399"), Color.parseColor("#10B981"), Color.parseColor("#064E3B"))
            Mode.PAUSED -> intArrayOf(Color.WHITE, Color.parseColor("#FBBF24"), Color.parseColor("#D97706"), Color.parseColor("#451A03"))
            Mode.IDLE -> intArrayOf(Color.WHITE, Color.parseColor("#A5B4FC"), Color.parseColor("#6366F1"), Color.parseColor("#1E1B4B"))
        }
        corePaint.shader = RadialGradient(
            cx - currentRadius * 0.25f, cy - currentRadius * 0.25f, currentRadius,
            coreColors, floatArrayOf(0f, 0.25f, 0.7f, 1.0f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, currentRadius, corePaint)

        // 4. Progress Arc
        if (progressPercent > 0f) {
            val progressRadius = currentRadius * 1.15f
            val sweep = (progressPercent / 100f) * 360f
            canvas.drawArc(
                cx - progressRadius, cy - progressRadius,
                cx + progressRadius, cy + progressRadius,
                -90f, sweep, false, progressPaint
            )
        }

        // 5. Swirling Ambient Particles
        particles.forEach { p ->
            p.angle += p.angularSpeed
            val px = cx + cos(p.angle) * (currentRadius + p.distance * 0.4f)
            val py = cy + sin(p.angle) * (currentRadius * 0.8f + p.distance * 0.3f)
            particlePaint.color = Color.argb(p.alpha, 0, 240, 255)
            canvas.drawCircle(px, py, p.size, particlePaint)
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        animator.cancel()
    }
}
